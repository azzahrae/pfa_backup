<?php

namespace App\Http\Controllers;
require_once(app_path('Libraries/xml2json.php'));
use SimpleXMLElement;
use Clearstream\XmlToArray\XmlToArray;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use PrestaShopWebservice;
use PrestaShopWebserviceException;
use Auth;

class SupplierDashboardController extends Controller
{
    public function index()
    {
        // Récupérer l'id_supplier de l'employé authentifié
        //$id_supplier = 2; // Remplacez par votre logique pour obtenir l'id_supplier
        $id_supplier = session('id_supplier'); // 0 est la valeur par défaut si l'ID du fournisseur n'est pas défini dans la session

        // Récupérer les produits du fournisseur avec l'id_supplier spécifié
        $webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        $productsXml = $webService->get([
            'resource' => 'products',
            'filter[id_supplier]' => '[' . $id_supplier . ']',
            'display' => 'full', 'limit' => 5
        ]);
        $products1= xmlToArray($productsXml);
        $products=$products1['prestashop']['products']['product'];
        /*echo '<pre>';
        print_r($products);
        echo '<pre>';
        die();*/
        // Retourner la vue dashboard avec les produits du fournisseur
        $title='Supplier Dashboard';
        
        return view('welcome', ['supplierProducts' => $products, 'title'=>$title]);
    }
}

