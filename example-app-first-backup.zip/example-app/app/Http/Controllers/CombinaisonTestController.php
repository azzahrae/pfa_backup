<?php

namespace App\Http\Controllers;
require_once(app_path('Libraries/xml2json.php'));//pour convertir un objet xml en array
use Illuminate\Http\Request;
use PrestaShopWebservice;
use PrestaShopWebserviceException;
set_time_limit(300); // 300 seconds = 5 minutes


class CombinaisonTestController extends Controller
{
    public function index()
    {   $id_supplier = session('id_supplier');
        $webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        $productsXml = $webService->get([
            'resource' => 'products',
            'filter[id_supplier]' => '[' . $id_supplier . ']',
            'display' => 'full'
        ]);
        /*echo '<pre>';
        print_r($this->getProductOptionValuesByIdOption($webService, 10));
        echo '</pre>';
        die();*/
        
        $combinaisonsXml = $webService->get(['resource' => 'combinations','display' => 'full']);
        $combinaisons = xmlToArray($combinaisonsXml);
        $products = xmlToArray($productsXml);
        /*echo '<pre>';
        print_r($combinaisons);
        echo '</pre>';
        die(); */

        $final=[];
        foreach($products['prestashop']['products']['product'] as $product){

            $id_product=$product['id'];
            $options=[]; // Initialiser le tableau des options pour chaque produit
        
            foreach($combinaisons['prestashop']['combinations']['combination'] as $combinaison){
                if($id_product==$combinaison['id']){
                    $quantity=$combinaison['quantity'];
                    $options[]=$quantity; // Ajouter la quantité au tableau des options
        
                    if(isset($combinaison['associations']['product_option_values']['product_option_value'])){
                        $associations=$combinaison['associations']['product_option_values']['product_option_value'];
        
                        foreach($associations as $association){
                            $options[]=$this->getProductOptionValuesByIdOption($webService, $association['id']); // Ajouter l'id de l'option au tableau des options
                        }
                    }
                }
            
            }
            $final[$id_product]=$options; // Ajouter le tableau d'options au tableau final
        }
       
        echo '<pre>';
        print_r($final);
        echo '</pre>';
        die();
        

        /*foreach($final as $f){
            $F=[];
            foreach($f as $option){
                $F[]=$option;
            }
            
        }
        echo '<pre>';
        print_r($F);
        echo '</pre>';
        die();*/
        /*foreach($products['prestashop']['products']['product'] as $product){

            $id_product=$product['id'];
            $options=[]; // Initialiser le tableau des options pour chaque produit
        
            foreach($combinaisons['prestashop']['combinations']['combination'] as $combinaison){
                if($id_product==$combinaison['id']){
                    $quantity=$combinaison['quantity'];
                    $options['quantity']=$quantity; // Ajouter la quantité au tableau des options
        
                    if(isset($combinaison['associations']['product_option_values']['product_option_value'])){
                        $associations=$combinaison['associations']['product_option_values']['product_option_value'];
        
                        foreach($associations as $association){
                            $options['options'][]=$association['id']; // Ajouter l'id de l'option au tableau des options
                        }
                    }
                }
            
            }
            $final[$id_product]=$options; // Ajouter le tableau d'options au tableau final
        }*/
        
        /*echo '<pre>';
        print_r($final);
        echo '</pre>';
        die();*/
        $newFinal = array_map(function($product) use ($webService) {
            $options = implode(',', array_map(function($option) use ($webService) {
                return $this->getProductOptionValuesByIdOption($webService, $option);
            }, $product['options']));
            return $product['quantity']  . ' '. $options;
        }, $final);
        
        echo '<pre>';
        print_r($newFinal);
        echo '</pre>';
        die();
        
        echo '<pre>';
        print_r($newFinal);
        echo '</pre>';
        die();
        


        $lastFinal = [];
        


        foreach ($final as $product) {
            echo $product[O];

            /*$opt = [];
            $opt[] = $product['quantity'];

            foreach ($product['options'] as $option) {
                $texte = $this->getProductOptionValuesByIdOption($webService, $option);
                $opt[] = $texte;
            }
        //je dois indexer par l'id produit
            $lastFinal[] = $opt;*/
        }

        echo '<pre>';
        print_r($lastFinal);
        echo '</pre>';
        die();
        //Récupération des noms
        /*foreach ($final as $f){
            $id_product=$f['id'];
            if(isset($products[$id_product]['product_option_values']['proc']))
        }*/
                


// Tableau associatif pour stocker les IDs de produits et les IDs de valeurs d'options
/*$associationsArray = [];

foreach ($products['prestashop']['products']['product'] as $product) {
    $productId = $product['id'];

    // Vérifier si l'association existe pour le produit actuel
    if (isset($product['associations']['product_option_values']['product_option_value'])) {
        $optionValues = $product['associations']['product_option_values']['product_option_value'];

        // Tableau pour stocker les IDs de valeurs d'options pour le produit actuel
        $optionValueIds = [];

        // Parcourir les IDs de valeurs d'options
        foreach ($optionValues as $optionValue) {
            $optionValueIds[] = $optionValue['id'];
        }

        // Stocker les IDs de produit et les IDs de valeurs d'options dans le tableau associatif
        $associationsArray[$productId] = $optionValueIds;
    }
}

// Afficher le tableau associatif
echo '<pre>';
print_r($associationsArray);
echo '</pre>';
die();*/

        //$products = xmlToArray($productsXml);
        foreach ($products['prestashop']['products']['product'] as $product) {
            $productId = $product['id'];
        
            // Récupérer les combinaisons du produit actuel
            $combinaisonsXml = $webService->get(['resource' => 'combinations', 'filter[id_product]' => $productId, 'display' => 'full']);
            $combinaisons = xmlToArray($combinaisonsXml);
        
            // Traitement des combinaisons du produit actuel
            // Par exemple, affichage des combinaisons
            echo 'Combinaisons pour le produit avec l\'ID ' . $productId . ':';
            echo '<pre>';
            print_r($combinaisons);
            echo '</pre>';
        }
        die();
        echo '<pre>';
        print_r($products);
        echo '<pre>';
        die();
        $combinaisonsXml = $webService->get(['resource' => 'combinations', 'display' => 'full']);
        $combinaisons = xmlToArray($combinaisonsXml);
        echo '<pre>';
        print_r($combinaisons);
        echo '<pre>';
        /*$webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        $productsXml = $webService->get(['resource' => 'products', 'display' => 'full']);
        $products = xmlToArray($productsXml);

        foreach ($products['prestashop']['products']['product'] as $product) {
        // Récupérer l'id du produit
        $productId = $product['id'];
        
        // Récupérer les combinaisons pour ce produit
        $combinaisonsXml = $webService->get(['resource' => 'combinations', 'filter[id_product]' => $productId, 'display' => 'full']);
        $combinaisons = xmlToArray($combinaisonsXml);

        // Traitement des combinaisons pour ce produit
        // Par exemple, affichage des combinaisons pour chaque produit
        echo 'Combinaisons pour le produit avec l\'ID ' . $productId . ':';
        echo '<pre>';
        print_r($combinaisons);
        echo '</pre>';
        
    }*/









}
function getProductOptionValuesByIdOption($webService, $id_option) {
    try {
        $productOptionValuesXml = $webService->get([
            'resource' => 'product_option_values',
            'filter[id]' => '[' . $id_option . ']',
            'display' => 'full'
        ]);
        $productOptionValues = xmlToArray($productOptionValuesXml);
        return $productOptionValues['prestashop']['product_option_values']['product_option_value']['name']['language'][0]['$'];
    } catch (PrestaShopWebserviceException $e) {
        echo "erreur dans la fct getProductOptionValuesBy";
        return null;
    }
}

}

?>