<?php


namespace App\Http\Controllers;
require_once(app_path('Libraries/xml2json.php'));//pour convertir un objet xml en array
use Illuminate\Http\Request;
use PrestaShopWebservice;
use PrestaShopWebserviceException;
set_time_limit(300); // 300 seconds = 5 minutes
class CouleurDeclinaisonController extends Controller
{
    public function index()
    {   //Pour le fournisseur en session
        //$id_supplier = session('id_supplier');
        $webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        $productsXml = $webService->get(['resource' => 'products', 'display' => 'full']);
        $options = $webService->get(['resource' => 'product_option_values', 'display' => 'full']);
        $products = xmlToArray($productsXml);
        $pd=$products['prestashop']['products']['product'];
        
        $ps=[];
        $S=[];
        foreach ($pd as $p) {
            if (isset($p['associations']['product_option_values']['product_option_value'])) {
                $S = []; // Réinitialiser $S pour chaque produit
                foreach ($p['associations']['product_option_values']['product_option_value'] as $ss) {
                    $S[] = $ss['id']; // Ajouter l'id de l'option de produit à $S
                }
                $SS[] = $S; // Ajouter $S à $SS après avoir parcouru toutes les valeurs d'options de produit pour ce produit
            }
        }
        
        
        
        
        //Maintenant $SS contient un tableau qui contient les ids des couleurs 
        // Initialiser le tableau pour stocker les noms des couleurs
        $couleurs = [];
        $couleur_tableau=[];
        // Parcourir chaque tableau contenant les IDs des couleurs
        foreach ($SS as $tableau) {
            

            $couleur_tableau = [];
            // Parcourir les IDs des couleurs dans le tableau actuel
            foreach ($tableau as $id_couleur) {
                
                // Récupérer les données de la couleur en utilisant l'ID
                $data = $webService->get(['resource' => 'product_option_values', 'id' => (int)$id_couleur]);
                
                $couleur_data = xmlToArray($data);
                /*echo '<pre>';
                print_r($couleur_data['prestashop']['product_option_value']['name']['language'][0]['$']);
                echo '<pre>';
                die();*/
                $couleur=$couleur_data['prestashop']['product_option_value']['name']['language'][0]['$'];
                // Vérifier si la couleur est valide avant de l'ajouter
                if ($this->estCouleur($couleur)) {
                    $couleur_tableau[] = $couleur;
                }
               
                
                
            }
            
            //$couleur_tableau []=$couleur_data['prestashop']['product_option_value']['name']['language'][0]['$'];
           // Ajouter le tableau des couleurs du tableau actuel au tableau principal
            $couleurs[] = $couleur_tableau;
            
        }
       

        //Le tableau final qui contient les id_product et les couleurs correspondantes
        $i=0;
        $finalArray=[];
        foreach($pd as $p){
            $key=$p['id'];
            if($i<count($couleurs)){
                //$value=$couleurs[$i];
                $finalArray []= [
                $key => $couleurs[$i]
            ];
            }
            $i++;
            
            
        }
        
        return view('all-products')->with('couleurs', $finalArray);

        
    }
    function estCouleur($couleur) {
        // Liste des couleurs possibles
        $couleursPossibles = ['Gris', 'Taupe', 'Beige', 'Blanc', 'Blanc cassé', 'Rouge', 'Noir', 'Camel', 'Orange', 'Bleu', 'Vert', 'Jaune', 'Marron', 'Rose'];
    
        // Vérifier si la couleur est dans la liste des couleurs possibles
        return in_array($couleur, $couleursPossibles);
    }
}
