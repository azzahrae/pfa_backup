<?php

namespace App\Http\Controllers;
require_once(app_path('Libraries/xml2json.php'));//pour convertir un objet xml en array

use PrestaShopWebservice;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use PrestaShopWebserviceException;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http; 

class LoginController extends Controller
{
    public function index()
    {
       
        return view('login');
        
    }
    public function authenticate(Request $request)
    {
        $email = $request->input('email');
        $password=$request->input('password');
        /*echo $email;
        echo "    ";
        echo $password;
        die();*/
        //En utilisant l'api
        $webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        // Get the zones
        $employeeXml = $webService->get(['resource' => 'employees', 'display' => 'full']);
        // Récupérer l'employé en fonction de l'email en utilisant l'API
        $employeeXml = $webService->get([
        'resource' => 'employees',
        'filter[email]' => '[' . $email . ']',
        'display' => 'full'
    ]);
        
        $employee = xmlToArray($employeeXml);
        //var_dump ($employee);
        //die();
       // Récupérer l'employé en fonction de l'email en utilisant directement la bdd
        /*$employee = DB::table('ps_employee')
                        ->where('email', $email)
                        ->first();*/
        /*echo '<pre>';
        print_r($employee);
        echo '<pre>';
        die();*/
        
        if ($employee && password_verify($password, $employee['prestashop']['employees']['employee']['passwd'])) {
            // L'authentification a réussi
            //Récupérer le nom et le prénom de l'employé authentifié pour navigation
            $request->session()->put('firstName', $employee['prestashop']['employees']['employee']['firstname']);
            $request->session()->put('lastName', $employee['prestashop']['employees']['employee']['lastname']);
            $request->session()->put('id_supplier', $employee['prestashop']['employees']['employee']['id_supplier']);
            $request->session()->regenerate();
            
            //return redirect()->route('dashboard');
            return redirect()->route('supplier.dashboard');

        } else {
            // L'authentification a échoué
            return back()->withErrors([
                'loginError' => 'Email or password incorrect.',
            ]);
        }
        }
}
