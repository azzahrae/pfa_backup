<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        /*$currency = '$'; // ou toute autre devise par défaut que vous souhaitez utiliser
        $total='-';
        return view('welcome', [
            'total' => $total,
            'currency' => $currency,
        ]);*/
        $title = 'Mon titre'; // Remplacez 'Votre Titre' par le titre que vous souhaitez afficher
        
        return view('welcome', ['title' => $title]);
        
    }
}
