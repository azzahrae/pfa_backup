<?php

namespace App\Http\Controllers;
require_once(app_path('Libraries/xml2json.php'));
use SimpleXMLElement;
use Clearstream\XmlToArray\XmlToArray;

use PrestaShopWebservice;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use PrestaShopWebserviceException;

class DashboardController extends Controller
{
    public function __construct()
    {
        // Pas besoin d'appeler parent::__construct() ici car cela n'a pas de sens dans un contrôleur Laravel
        // $this->load->library('prestashop_webservice'); // Cette ligne n'est pas nécessaire en Laravel
    }
    
    public function index()
    {
        try {
            // Create an instance of PrestaShopWebservice
            $webService = new PrestaShopWebservice('http://localhost/prestashop', '2T2BJFSHPMX2VZQ7US9GF15TS82Y14QQ', false);
        
            // Get the orders
            $ordersXml = $webService->get(['resource' => 'orders', 'display' => 'full','sort' => '[date_add_DESC]', 'date'=> 1]);
            $orders = xmlToArray($ordersXml);
            //Get the products
            $productsXml = $webService->get(['resource' => 'products', 'display' => 'full', 'limit' => 5]);
            $products = xmlToArray($productsXml);
            //dd($products);
            /*echo '<pre>';
            print_r($orders);
            echo '<pre>';
            die();*/
            $productData=[];
        
            foreach ($products['prestashop']['products']['product'] as $product) {
                $reference = isset($product['reference']) ? (is_array($product['reference']) ? (count($product['reference']) !== 0 ? $product['reference']['$'] : '-') : $product['reference']) : '-';
                $productType = isset($product['type']) ? (is_array($product['type']) ? (count($product['type']) !== 0 ? $product['type']['$'] : '-') : $product['type']) : '-';
                $redirectType = isset($product['redirect_type']) ? (is_array($product['redirect_type']) ? (count($product['redirect_type']) !== 0 ? $product['redirect_type']['$'] : '-') : $product['redirect_type']) : '-';
                $price = isset($product['price']) ? (is_array($product['price']) ? (count($product['price']) !== 0 ? $product['price']['$'] : '-') : $product['price']) : '-';
                $condition = isset($product['condition']) ? (is_array($product['condition']) ? (count($product['condition']) !== 0 ? $product['condition']['$'] : '-') : $product['condition']) : '-';
                
                // Utilisez les variables $reference, $productType, $redirectType, $price et $condition comme vous le souhaitez
                $productData[] = [
                    'reference' => $reference,
                    'product_type' => $productType,
                    'redirect_type' => $redirectType,
                    'price' => $price,
                    'condition' => $condition,
                    
                ];
            
            }
           
            
            $orderData = [];
            foreach ($orders['prestashop']['orders']['order'] as $order) {
                // Récupérer l'ID de la commande
                $orderId = $order['id'];

                // Récupérer l'ID du client
                
                $customerId = is_array($order['id_customer']) ? $order['id_customer']['$'] : $order['id_customer'];
                // Récupérer le nom du client
                $customerData = $this->getCustomer($webService, $customerId);
                $customerName = $customerData['firstname'] . ' ' . $customerData['lastname'];

                // Récupérer l'adresse de livraison
                $deliveryAddressId = is_array($order['id_address_delivery']) ? $order['id_address_delivery']['$'] : $order['id_address_delivery'];
                // Récupérer le code postal de l'adresse de livraison
                //dd($deliveryAddressId);
                $postalCode = $this->getPostalCode($webService, $deliveryAddressId);
                

                // Récupérer la date d'ajout de la commande
                $dateAdded = $order['date_add'];

                // Récupérer l'état actuel de la commande
                $currentState = is_array($order['current_state']) ? $order['current_state']['$'] : $order['current_state'];

                // Récupérer les détails supplémentaires si nécessaire
                /*$customer = $this->getCustomer($webService, $customerId);
                $postalCode = $this->getPostalCode($webService, $deliveryAddressId);
                $carrier = $this->getCarrier($webService, $deliveryAddressId);
                $status = $this->getStatus($webService, $currentState);*/

                // Ajouter les données de la commande au tableau
                $orderData[] = [
                    'id' => $orderId,
                    'id_customer' => $customerId,
                    'customerName' => $customerName,
                    'postal_code' => $postalCode,
                    //'module' => $module,
                    //'employee_id' => $employeeId,
                    'date_add' => $dateAdded,
                    'current_state' => $currentState,
                ];
            }
            $totalClients = count(array_unique(array_column($orderData, 'id_customer')));
            $totalOrders = count($orderData);
            $totalProducts = 1000;
            // Passer les données à la vue
            return view('welcome', [
                'orders' => $orderData,
                'totalClients' => $totalClients,
                'totalOrders' => $totalOrders,
                'totalProducts' => $totalProducts,
                'title' => 'Dashboard',
                'products' => $productData
            ]);
            
        }            
        catch (PrestaShopWebserviceException $ex) {
            // Gestion des exceptions
            return response()->json(['error' => $ex->getMessage()], 500);
        }
    }

    // Méthodes de récupération des données supplémentaires
    private function getCustomer($webService, $customerId)
    {
        // Call to retrieve customer details
        $customer = $webService->get(['resource' => 'customers', 'id' => $customerId]);
        return (array)$customer->customer;
    }

    private function getPostalCode($webService, $addressId)
    {
        // Call to retrieve address details
        $address = $webService->get(['resource' => 'addresses', 'id' => $addressId]);
        return (string)$address->address->postcode;
    }

    private function getCarrier($webService, $carrierId)
    {
        // Call to retrieve carrier details
        $carrier = $webService->get(['resource' => 'carriers', 'id' => $carrierId]);
        return (array)$carrier->carrier;
    }

    private function getStatus($webService, $statusId)
    {
        // Call to retrieve order status details
        $status = $webService->get(['resource' => 'order_states', 'id' => $statusId]);
        return (array)$status->order_state;
    }
}
