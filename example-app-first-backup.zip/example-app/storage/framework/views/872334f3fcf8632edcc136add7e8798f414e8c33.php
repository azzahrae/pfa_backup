<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?> | ORDER</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Conception & Réalisation PixisWeb -->
    <meta name="web_author" content="Pixisweb">

    <!-- Theme style -->
    <link href="<?php echo e(asset('asset/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/admin.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('asset/css/base/jquery-ui-1.10.4.custom.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Date and Time Picker CSS -->
    <link href="<?php echo e(asset('asset/css/datepicker.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/timepicker.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/skins.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/loader.css')); ?>" rel="stylesheet">

    <!-- All Icon  CSS -->
    <link href="<?php echo e(asset('asset/css/font-icons/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/font-icons/entypo/css/entypo.css')); ?>" >

    <!-- Data Table  CSS -->
    <!-- <link href="<?php echo e(asset('asset/css/plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet" type="text/css" /> -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('asset/js/html5shiv.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('asset/js/respond.min.js')); ?>" type="text/javascript"></script>
    <![endif]-->
    <script src="<?php echo e(asset('asset/js/jquery-1.10.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/jquery-ui-1.10.4.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/jquery-loader.js')); ?>" type="text/javascript"></script>

    <!-- ALl Custom Scripts -->
    <script src="<?php echo e(asset('asset/js/admin.js')); ?>"></script>

    <!-- Chosen for search in select list -->
    <link href="<?php echo e(asset('asset/js/chosen/chosen.min.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(asset('asset/js/chosen/chosen.jquery.js')); ?>"></script>

    <meta name="robots" content="noindex">
    <meta name="google-site-verification" content="Pvtsk7aZGnooWc4OLq-h5K2VR12YvfglBTAZSlpMlQo" />
</head>
<body>
    <div class="text-primary"></div>

    <!-- DataTables JS -->
    <script src="<?php echo e(asset('asset/js/plugins/dataTables/jquery.dataTables.js')); ?>"></script>
    <!--<script src="<?php echo e(asset('asset/js/plugins/dataTables/dataTables.bootstrap.min.js')); ?>"></script> -->
    <!--<script src="<?php echo e(asset('asset/js/plugins/dataTables/dataTables.min.js')); ?>"></script>-->
    <script src="<?php echo e(asset('asset/js/plugins/dataTables/dataTables.tableTools.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/plugins/dataTables/dataTables.bootstrap.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            // Initialisation de DataTables
            $('#example').DataTable();
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\HP EliteBook 840 G6\example-app\resources\views/components/header.blade.php ENDPATH**/ ?>