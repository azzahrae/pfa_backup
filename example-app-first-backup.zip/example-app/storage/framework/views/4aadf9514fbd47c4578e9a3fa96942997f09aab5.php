<section class="content" style="padding-left: 250px;">
    <div class="row">
        <!-- Left col -->
        <div class="col-md-9">
            <!-- TABLE: LATEST ORDERS -->
            <div class="box">
                <div class="box-header box-header-background with-border">
                    <h3 class="box-title">Dernières commandes</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table no-margin">
                            <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Client</th>
                                    <th>Code postal</th>
                                    <th>Type de commande</th>
                                    <th>Représentant</th>
                                    <th>Date</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order['id']); ?></td>
                                    <td><?php echo e($order['customerName']); ?></td>
                                    <td><?php echo e($order['postal_code']); ?></td>
                                    <td>Commande en ligne</td>
                                    <td>Représentant</td>
                                    <td><?php echo e($order['date_add']); ?></td>
                                    <td><?php echo e($order['current_state']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="#" class="btn btn-sm bg-navy btn-flat pull-left">Nouvelle Commande</a>
                    <a href="#" class="btn btn-sm bg-purple btn-flat pull-right">Voir toutes les Commandes</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->

        <!-- Right col -->
        <div class="col-md-3">
            <!-- Info boxes -->
            <div class="info-box bg-yellow box">
                
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="glyphicon glyphicon-qrcode"></i></span>
            
                    <div class="info-box-content box-color">
                        <span class="info-box-text">TOTAL PRODUITS</span>
                        <span class="info-box-number"><?php echo e($totalProducts); ?></span>
                        <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                    <!-- /.info-box-content -->
                </div>
            
                <!-- /.info-box-content -->
            </div>
            <div class="info-box bg-yellow box">
                
                <div class="info-box">
                    <span class="info-box-icon bg-purple"><i class="glyphicon glyphicon-shopping-cart"></i></span>
            
                    <div class="info-box-content box-color">
                        <span class="info-box-text">TOTAL COMMANDES</span>
                        <span class="info-box-number"><?php echo e($totalOrders); ?></span>
                        <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <div class="info-box bg-aqua box">
                <div class="info-box">
                    <span class="info-box-icon bg-yellow"><i class="glyphicon glyphicon-user"></i></span>
            
                    <div class="info-box-content box-color">
                        <span class="info-box-text">TOTAL CLIENTS</span>
                        <span class="info-box-number"><?php echo e($totalClients); ?></span>
                        <a href="#" class="small-box-footer">Plus d'infos <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <!-- Produit LIST -->
    <div class="row">
        <div class="col-md-9">
            <div class="box box-primary">
                <div class="box-header box-header-background with-border">
                    <h3 class="box-title">Produits récemment ajoutés</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Réf</th>
                                <th>Product type</th>
                                <th>Redirect type</th>
                                <th>Price</th>
                                <th>Condition</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product['reference']); ?></td>
                                <td><?php echo e($product['product_type']); ?></td>
                                <td><?php echo e($product['redirect_type']); ?></td>
                                <td><?php echo e($product['price']); ?></td>
                                <td><?php echo e($product['condition']); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="#" class="btn btn-sm bg-navy btn-flat pull-left">Nouveau Produit</a>
                    <a href="#" class="btn btn-sm bg-purple btn-flat pull-right">Voir tous les Produits</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<?php /**PATH C:\Users\HP EliteBook 840 G6\example-app\resources\views/dashboard.blade.php ENDPATH**/ ?>