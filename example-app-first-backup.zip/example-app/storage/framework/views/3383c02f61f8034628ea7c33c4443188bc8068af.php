<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <?php
                    $user_pic = 'default.jpg'; // Définir une image par défaut si l'image de l'utilisateur n'est pas définie
                ?>
                <img src="<?php echo e(asset('img/user/' . $user_pic)); ?>" class="img-circle" alt="User Image"/>
            </div>
            <div class="pull-left info" style="padding-top: 15px">
                <p><?php echo e(Auth::user()->name); ?></p>
            </div>
        </div>
        <!-- Menu dynamique à remplacer par votre logique de menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MENU</li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
        </ul>
    </section>
</aside>
<?php /**PATH C:\Users\HP EliteBook 840 G6\example-app\resources\views/navigation.blade.php ENDPATH**/ ?>