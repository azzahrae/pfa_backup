<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEST</title>
</head>
<body>
    
</body>
</html><?php /**PATH C:\Users\HP EliteBook 840 G6\example-app\resources\views/test.blade.php ENDPATH**/ ?>