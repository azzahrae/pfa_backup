<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AllProductController;
use App\Http\Controllers\PrestaShopController;
use App\Http\Controllers\CombinaisonTestController;
use App\Http\Controllers\TestDeclinaisonController;
use App\Http\Controllers\SupplierDashboardController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
  //  return view('welcome');
//});

Route::get('/hello-world', [PrestaShopController::class, 'index']);
//Pour dashboard
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/', [LoginController::class, 'index'])->name('login');
Route::post('/authenticate', [LoginController::class, 'authenticate'])->name('authenticate');
//Pour dashboard personnalisé pour chaque fournisseur 
Route::get('/supplierdashboard', [SupplierDashboardController::class, 'index'])->name('supplier.dashboard');
//Pour tester les déclinaisons
Route::get('/testdeclinaison', [TestDeclinaisonController::class, 'index'])->name('test.declinaison');
//Route::get('/testdeclinaison', 'TestDeclinaisonController@index');
//Pour afficher tous les produits
Route::get('/all-products', [AllProductController::class, 'index'])->name('all.products');
//Pour afficher les détails de chaque produit
Route::get('/product/details/{productId}', [AllProductController::class, 'getProductDetails']);
//Pour tester les combinaisons des options
Route::get('/combinaisons', [CombinaisonTestController::class, 'index'])->name('all.combinaison');


