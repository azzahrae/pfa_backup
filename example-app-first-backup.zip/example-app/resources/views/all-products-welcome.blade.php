@include('components.header')
@include('components.user_profile')
@include('components.navigation')
{{-- @include('dashboard') pour dashboard complète--}}
@include('all-products')





<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Market Place</title>
</head>
@yield('content')

    <!-- Scripts communs à toutes les pages -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <!-- Scripts spécifiques à chaque page -->
    @yield('scripts')
</html>

@include('components.footer')








