<section class="content" style="padding-left: 250px;">
    <div class="row">
        <!-- Left col -->
        <div class="col-md-9">
            <!-- TABLE: LATEST ORDERS -->
            <div class="box">
                <div class="box-header box-header-background with-border">
                    <h3 class="box-title">Dernières commandes du fournisseur</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table no-margin">
                            <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Client</th>
                                    <th>Code postal</th>
                                    <th>Type de commande</th>
                                    <th>Représentant</th>
                                    <th>Date</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="#" class="btn btn-sm bg-navy btn-flat pull-left">Nouvelle Commande</a>
                    <a href="#" class="btn btn-sm bg-purple btn-flat pull-right">Voir toutes les Commandes</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->

        <!-- Right col -->
        <div class="col-md-3">
            <!-- Info boxes -->
            <!-- Vous pouvez ajouter ici les info-boxes spécifiques au fournisseur -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <!-- Produit LIST -->
    <div class="row">
        <div class="col-md-9">
            <div class="box box-primary">
                <div class="box-header box-header-background with-border">
                    <h3 class="box-title">Produits récemment ajoutés</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Réf</th>
                                <th>Product type</th>
                                <th>Redirect type</th>
                                <th>Price</th>
                                <th>Condition</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            @foreach($supplierProducts as $product)
                            <tr>
                                <td>{{ !empty($product['reference']) ? $product['reference'] : '0' }}</td>
                                <td>{{ !empty($product['product_type']) ? $product['product_type'] : '0' }}</td>
                                <td>{{ !empty($product['redirect_type']) ? $product['redirect_type'] : '0' }}</td>
                                <td>{{ !empty($product['price']) ? $product['price'] : '0' }}</td>
                                <td>{{ !empty($product['condition']) ? $product['condition'] : '0' }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="#" class="btn btn-sm bg-navy btn-flat pull-left">Nouveau Produit</a>
                    <a href="{{ route('all.products') }}" class="btn btn-sm bg-purple btn-flat pull-right">Voir tous les Produits</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
