

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
function showProductDetailsModal(colors) {
    // Afficher le modal
    $('#productDetailsModal').modal('show');

    // Construire le contenu HTML des couleurs
    var detailsTable = '<table class="table"><thead><tr><th>Couleur</th><th>Taille</th><th>Quantité</th></tr></thead><tbody>';
    colors.forEach(function(color) {
        // Pour chaque couleur, ajouter une ligne avec une couleur et des tailles et quantités vides
        detailsTable += '<tr><td>' + color + '</td><td></td><td></td></tr>';
    });
    detailsTable += '</tbody></table>';

    // Afficher les détails du produit dans le modal
    $('#productDetailsModal .modal-body').html(detailsTable);
}



</script>
@endsection

@section('content')
<section class="content" style="padding-left: 250px;">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header box-header-background with-border">
                    <h3 class="box-title">Tous les produits</h3>
                </div>
                <div class="box-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Réf</th>
                                <th>Product type</th>
                                <th>Redirect type</th>
                                <th>Price</th>
                                <th>Condition</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($allProducts as $product)
                            <tr>
                                <td>{{ !empty($product['reference']) ? $product['reference'] : '0' }}</td>
                                <td>{{ !empty($product['product_type']) ? $product['product_type'] : '0' }}</td>
                                <td>{{ !empty($product['redirect_type']) ? $product['redirect_type'] : '0' }}</td>
                                <td>{{ !empty($product['price']) ? $product['price'] : '0' }}</td>
                                <td>{{ !empty($product['condition']) ? $product['condition'] : '0' }}</td>
                                <td>
                                    <button class="btn btn-info btn-sm product-details"
    data-colors="{{ !empty($finalArray[$loop->index][$product['id']]) ? json_encode($finalArray[$loop->index][$product['id']]) : '[]' }}"
    onclick="showProductDetailsModal({{ !empty($finalArray[$loop->index][$product['id']]) ? json_encode($finalArray[$loop->index][$product['id']]) : '[]' }})">
    Détails
</button>

                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="productDetailsModal" tabindex="-1" role="dialog" aria-labelledby="productDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="productDetailsModalLabel">Détails du produit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="productDetails"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

</section>
@endsection

