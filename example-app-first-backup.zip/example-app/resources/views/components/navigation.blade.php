<aside class="main-sidebar"  style="background-color: #001f3f;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
               
                <img src="{{ asset('asset/img/user.jpg') }}" class="img-circle" alt="User Image"/>
            </div>
            <div class="pull-left info" style="padding-top: 15px">
                <p>{{ session('firstName') }} {{ session('lastName') }}</p>
            </div>
        </div>
        <!-- Menu dynamique à remplacer par votre logique de menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="glyphicon glyphicon-th-large"></i> <span>Produits</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="glyphicon glyphicon-shopping-cart"></i> <span>Gestion des commandes</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="glyphicon glyphicon-user"></i> <span>Gestion des clients</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="glyphicon glyphicon-signal"></i> <span>Repports</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i> <span>Configuration</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="entypo-users"></i> <span>Gestion des utilisateurs</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
            </li>


        </ul>
    </section>
</aside>
<style>
    /* Styles personnalisés */
    .sidebar {
        /* Ajoutez vos styles CSS personnalisés ici */
        color: white; /* Texte blanc pour un meilleur contraste */
    }

    .sidebar-menu a {
        color: #b8c7ce; /* Liens blancs pour un meilleur contraste */
    }
</style>