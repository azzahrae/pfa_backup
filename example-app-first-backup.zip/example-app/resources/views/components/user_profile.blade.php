<header class="main-header" style="background-color: #2C3E50;">
    <!-- Logo -->
    <a href="{{ url('/') }}" class="logo"><b>My OUTLET</b> STORE</a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu pull-right">
            <ul class="nav navbar-nav">
                <!-- Messages: style can be found in dropdown.less-->
                
                    <!-- Notifications: style can be found in dropdown.less -->
                    <li class="dropdown messages-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-flag-o"></i>
                            <span class="label label-danger">0</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">0 Produits en rupture de stock</li>
                            <li>
                                <!-- inner menu: contains the actual data -->
                                <ul class="menu">
                                    <!-- Aucune notification -->
                                </ul>
                            </li>
                            <li class="footer"><a href="{{ url('admin/product/notification_product') }}">Voir toutes les notifications</a></li>
                        </ul>
                    </li>
                    <li class="dropdown messages-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="label label-warning">0</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">0 Commandes en cours</li>
                            <li>
                                <!-- inner menu: contains the actual data -->
                                <ul class="menu">
                                    <!-- Aucune commande en cours -->
                                </ul>
                            </li>
                            <li class="footer"><a href="{{ url('admin/order/pending_order') }}">Voir toutes les commandes en cours</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="{{ url('admin/employee/profil/' . Auth::id()) }}">
                            <span class="glyphicon glyphicon-user"></span> Mon Profil
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('login/logout') }}">
                            <span class="glyphicon glyphicon-off"></span> Déconnexion
                        </a>
                    </li>
              
            </ul>
        </div>
    </nav>
</header>
