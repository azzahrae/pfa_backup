<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} <span style="color: #005299">MY OUTLET Store</span>.</strong>
    Tous droits réservés.
</footer>
</div><!-- ./wrapper -->

<!-- AdminLTE App -->
<script src="{{ asset('asset/js/bootstrap.min.js') }}" type="text/javascript"></script>
<!--<script src="{{ asset('asset/js/menu.js') }}" type="text/javascript"></script>-->
<!--<script src="{{ asset('asset/js/custom-validation.js') }}" type="text/javascript"></script>-->
<script src="{{ asset('asset/js/jquery.validate.js') }}" type="text/javascript"></script>
<script src="{{ asset('asset/js/app.js') }}" type="text/javascript"></script>
<script src="{{ asset('asset/js/form-validation.js') }}" type="text/javascript"></script>
<script src="{{ asset('asset/js/additional-methods.min.js') }}" type="text/javascript"></script>
<!-- Jasny Bootstrap for NIce Image Change -->
<script src="{{ asset('asset/js/jasny-bootstrap.min.js') }}"></script>
<script src="{{ asset('asset/js/bootstrap-datepicker.js') }}"></script>
<script src="{{ asset('asset/js/timepicker.js') }}"></script>
<!-- Data Table -->
<!--<script src="{{ asset('asset/js/plugins/metisMenu/metisMenu.min.js') }}" type="text/javascript"></script>-->

<script src="{{ asset('asset/js/plugins/dataTables/jquery.dataTables.js') }}" type="text/javascript"></script>
<script src="{{ asset('asset/js/plugins/dataTables/dataTables.bootstrap.js') }}" type="text/javascript"></script>

<script>
    $(document).ready(function () {
        $('#dataTables-example').dataTable();
    });
</script>

<script src="{{ asset('asset/js/chartjs/Chart.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('asset/js/chartjs/dashboard.js') }}" type="text/javascript"></script>

</body>
</html>
